from socket import *
from termcolor import colored


def recv_message(clientSocket):
    while True:
        message = clientSocket.recv(1024).decode("utf-8")
        if "Your grade is " in message:
            print (colored(message, 'red'))
            clientSocket.close()
            exit(0)
        else:
            print (colored(message, 'blue'))
            send_answer(clientSocket)


def send_answer(clientSocket):
    message = input(colored('Type answer: ', 'cyan'))
    clientSocket.send(message.encode())
    if message == "exit":
        clientSocket.close()
        exit(0)


if __name__ == "__main__":
    serverName = gethostbyname(gethostname())
    serverPort = 12000
    clientSocket = socket(AF_INET,SOCK_STREAM)
    clientSocket.connect((serverName, serverPort))
    recv_message(clientSocket)
