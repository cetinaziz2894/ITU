from socket import *
import threading
from termcolor import colored


questions = []
questions.append(["2 + 5 = ?\nA) 5\tB) 6\tC) 7\tD) 8", "C"])
questions.append(["12 + 13 = ?\nA) 25\tB) 16\tC) 87\tD) 18", "A"])
questions.append(["53 - 23 = ?\nA) 50\tB) 36\tC) 30\tD) 28", "C"])
questions.append(["13 + 73 = ?\nA) 53\tB) 66\tC) 76\tD) 86", "D"])
questions.append(["0 + 0 = ?\nA) 0\tB) 1\tC) -1\tD) 10", "A"])


class ThreadedServer():

    def __init__(self, serverPort):
        try:
            serverSocket = socket(AF_INET, SOCK_STREAM)
        except:
            print (colored("Socket cannot be created!!!", 'red'))
            exit(1)
            
        print (colored("Socket is created...", 'green'))

        try:
            serverSocket.setsockopt(SOL_SOCKET, SO_REUSEADDR, 1)
        except:
            print (colored("Socket cannot be used!!!", 'red'))
            exit(1)

        print (colored("Socket is being used...", 'green'))

        try:
            serverSocket.bind(('',serverPort))
        except:
            print (colored("Binding cannot de done!!!", 'red'))
            exit(1)

        print (colored("Binding is done...", 'green'))

        try:
            serverSocket.listen(45)
        except:
            print (colored("Server cannot listen!!!", 'red'))
            exit(1)

        print (colored("The server is ready to receive", 'green'))

        try:
            self.listen_to_client(serverSocket)
        except:
            print (colored("Server cannot listen to client!!!", 'red'))
            exit(1)


    def send_questions(self, client, addr):
        grade = 0
        for idx, each in enumerate(questions):
            # print(idx, each[0])
            try:
                client.send(each[0].encode())
                message = client.recv(1024).decode("utf-8")
            except:
                print (colored("Server cannot the current question!!!", 'red'))
                exit(0)

            if message == "exit":
                print (colored(addr, 'yellow'), colored(" is closed extremely!", 'yellow'))
                # print (addr , " is closed!!!")
                client.close()
                exit(0)
            else:
                print (colored(addr, 'magenta'), colored(" answers: ", 'magenta'), colored(message, 'magenta'))
                grade += self.calculate_grades(idx, message)
        
        result = "Your grade is " + str(grade)
        client.send(result.encode())
        client.close()
        exit(0)


    def listen_to_client(self, serverSocket):
        while True:
            connectionSocket, addr = serverSocket.accept()
            threading.Thread(target = self.send_questions, args = (connectionSocket, addr)).start()


    def calculate_grades(self, idx, answer):
        if questions[idx][1] == answer.upper():
            return 20
        else:
            return 0


if __name__ == "__main__":
    serverPort=12000
    ThreadedServer(serverPort)