module Hw2_5 where
data Trie k a = Leaf a | Branch [(Maybe k, Trie k a)] deriving (Show)
empty' :: Trie k a 
empty' = Branch []
insert' :: Eq k => [k] -> a -> Trie k a -> Trie k a 
insert' k a (Branch [])
   | (length k)==0   = Branch [(Nothing,Leaf a)]
   | otherwise   = Branch [(Just (head k),(insert' (tail k) a (empty')))]
insert' k a (Branch x) 
    | (head k)== (removeJ (head x)) = conct (addj (Just (head k))(insert' (tail k) a (gettrie (head x)))) (tail x)
    | (length x)>1                  = Branch  (reverse ((head x):  removeB(insert' k a (Branch (tail x)))))
    | otherwise                     = Branch ( removeB(insert' k a (Branch []))++x)
        where 
            removeB (Branch x)= x
            removeJ (Just x,_)=x
            gettrie (_,x)=x
            addj a k = Branch [(a,k)]
            conct (Branch x) a = Branch (x++a)
fromList' :: Eq k => [([k], a)] -> Trie k a
fromList' [] =empty'
fromList'  ((k,a):xs) = insert' k a (fromList' xs)
lookup' :: Eq k => [k] -> Trie k a -> Maybe a
lookup' (x:xs) (Leaf _) = Nothing
lookup' [] (Branch [(Nothing,Leaf a)]) = (Just a)
lookup' []  _ =Nothing
lookup'   _  (Branch [])  = Nothing
lookup' k (Branch (x:xs))
    | (head k)== (removeJ x)      =  lookup' (tail k) (gettrie x)
    | otherwise                   =  lookup' k  (Branch xs)
        where 
            removeJ (Just x,_)=x
            gettrie (_,x)=x
            
ischild::Trie a k -> Bool
ischild (Leaf a) = True
ischild  (Branch [])= True
ischild (Branch x2)
    | (length x2)==1  = ischild (gettrie (head x2))
    | (length x2)>1   = False 
        where   
            gettrie (_,x1)=x1
delete' :: Eq k => [k] -> Trie k a -> Trie k a
delete' x y@(Branch list1)
    | (isNoth (lookup' x y) )                           = y
    | (ischild y)                                       = empty'
    | (length list1)==1                                 = Branch [(Just (head x),(delete' (tail x) (gettrie (head list1))))]
    | (head x)/= (removeJ (head list1))                 = conct1  ( delete' x  (Branch (tail list1))) ([head list1])
    | ischild  ( gettrie (head list1))                  = Branch (tail list1)
    | otherwise                                         = conct (Branch [(Just (head x),(delete' (tail x) (gettrie (head list1))))]) (tail list1)

        where
            getBr  (Branch e)=e
            removeJ (Just x1,_)=x1
            isNoth Nothing = True
            isNoth  _ = False
            gettrie (_,x)=x
            conct (Branch x) a = Branch (x++a)
            conct1 (Branch x) a = Branch (a++x)
            