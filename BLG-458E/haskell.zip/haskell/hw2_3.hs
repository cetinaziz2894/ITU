module HW2_3 where 
data BList a =List Limit [a] |Elist Limit deriving (Show)
type Limit = Int
empty :: Limit -> BList a 
empty x = Elist  x
fromList :: [a] -> BList a
fromList [] = Elist 0 
fromList x= List (length x) x
limited :: Limit -> BList a -> BList a
limited x (List _ y)
    | (x==0) || (length y ==0) = Elist x
    | x > (length y) = List x y
    | otherwise      = List x (take x y)
cons :: a -> BList a -> BList a 
cons a (Elist y)
    | y==0    = error "too many elements"
    | otherwise = List y [a]
cons a (List y z)
    | y==(length z)   = error "too many elements"
    | otherwise       = List y (a:z) 
concat’ :: [BList a] -> BList a 