def entry_exit(f): 
   def wrapped(x): 
       print("Entering with parameter: %s" % x) 
	   result = f(x) 
	   print("Exiting with result: %s" % result) 
	   return result 
	return wrapped
@entry_exit
def fac(n):
    return 1 if n==0 else n*(fac(n-1))