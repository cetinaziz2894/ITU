module HW2 where
data Date = Date Int Int Int
data Animal = Animal { 
    species :: String, 
    name :: String, 
    legNum :: Maybe Int, -- Will be Nothing if animal has no legs 
    birthday :: Date, 
    dangerLvl :: Int }
testDog = Animal "Dog" "Fluffy" (Just 4) (Date 16 3 1975) 10 
avgLegNum :: [Animal] -> Double
avgLegNum a= ( fromIntegral (sumLeg a))/ ( fromIntegral (length a))
    where
       sumLeg::[Animal]->Int
       sumLeg [] =0
       sumLeg (x:xs)=(getMaybe $legNum x)+  sumLeg xs
          where
             getMaybe::Maybe Int->Int
             getMaybe Nothing =0
             getMaybe  (Just x)=x
canDrinkBeer :: [Animal] -> [String]
canDrinkBeer [] = []
canDrinkBeer a = (getNames.filterAnm) a 
    where
       filterAnm::[Animal]->[Animal]
       filterAnm = filter (\ x-> (1999 >= getyear  (birthday x)) ) 	   
       getNames:: [Animal]->[String]
       getNames []=[]
       getNames (x:xs)=(name x): getNames xs
       getyear:: Date->Int
       getyear (Date _ _ x)=x
--canDrinkBeer x = filter 