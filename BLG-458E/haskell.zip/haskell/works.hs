module Works where
empty = do line <- getLine
           return (length line == 0)
dismiss (IO x) = x