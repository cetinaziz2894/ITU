module HW2__2 where
data BinaryTree a = Null | Node a (BinaryTree a) (BinaryTree a)
testTree = Node 1 (Node 2 (Node (-4) Null Null) (Node 3 Null Null)) (Node 2 (Node 1 Null (Node 10 Null (Node (-2) Null Null))) Null)
numNodes :: BinaryTree a -> Int 
numNodes Null =0
numNodes (Node _ x  y)=1+(numNodes x)+(numNodes y)
averageNodeDegree :: BinaryTree a -> Double
averageNodeDegree Null =0
averageNodeDegree n@(Node _ x y )= (fromIntegral((numNodes x)+(numNodes y)))/ ( fromIntegral (numNodes n))
treeDepth :: BinaryTree a -> Int
treeDepth Null=0
treeDepth (Node _ x y)= 1+ max (treeDepth x) (treeDepth y)
preorder:: BinaryTree a -> [a] 
preorder Null=[]
preorder (Node a x y)= [a] ++ (preorder x) ++(preorder y)
inorder :: BinaryTree a -> [a]
inorder Null=[]
inorder (Node a x y)= (inorder x)++ [a]++ (inorder y )
postorder :: BinaryTree a -> [a] 
postorder Null=[]
postorder (Node a x y)=(postorder x)++(postorder y) ++ [a] 